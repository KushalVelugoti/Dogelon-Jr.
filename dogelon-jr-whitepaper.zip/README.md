# Dogelon Jr. ($DLJ) Whitepaper

Welcome to the official repository for the **Dogelon Jr. Whitepaper**.  
Dogelon Jr. is a meme-based BEP-20 token launched on the Binance Smart Chain with the goal of creating a fun, community-driven ecosystem.

📄 [Read the full whitepaper](./WHITEPAPER.md)

---

## Links
- Official Telegram: [t.me/DogelonJr_official](https://t.me/DogelonJr_official)
- Twitter: [twitter.com/DogelonJr](https://twitter.com/DogelonJr)
- Website: Coming soon
